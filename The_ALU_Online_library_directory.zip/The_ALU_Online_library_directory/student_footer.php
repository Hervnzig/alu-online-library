<!DOCTYPE html>
<html>
<head>
	<title></title>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="stylesFolder/admin_styles.css">
</head>
<body>
<footer>
	<br>
	<h3>Contact us through social media</h3><br>

	<div>

		<a href="#"><img src="images/icons/instagram.png"></a>
        <a href="#"><img src="images/icons/facebook.png"></a>
        <a href="#"><img src="images/icons/twitter-logo-on-black-background.png"></a>
	</div>

	<br>
	<p>Email:&nbsp Online.library@gmail.com </p>
		<br><br>
	<p>Mobile:&nbsp &nbsp +880171*******</p>
</footer>
</body>
</html>